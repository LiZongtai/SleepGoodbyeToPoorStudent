﻿In the following the fields of the download file from EcoSystemData are described, in case you need more detailed information you can contact us by sending an email to ecosystemdata@ices.dk

DateTime - In some cases the DateTime is estimated by ICES DC, -in these cases there will be a note in the download field "ICES DataTime Note"

Longitude [degrees_east] - In some cases the Latitude has been estimated by ICES DC, -in these cases there will be a note in the download field "ICES Position Note"

Longitude [degrees_east] - In some cases the Longitude has been estimated by ICES DC, -in these cases there will be a note in the download field "ICES Position Note"

Depth [m] - Depth in meters ( in the cases of datasets "Contaminants and biological effects" and "Biological community" this is the upper depth of the depth range (DEPHU)

Parameter - Parameter being mesured, see this page for a list of parameters: http://vocab.ices.dk/?ref=37

Value - The value of the parameter, some times the value may have undergone a unit conversion to be comparable with other data values. In these cases there will be a field in the download "Original value".

Unit - Units of the value, see this page for a complete list of the units: http://vocab.ices.dk/?ref=155

Species - The species latin name

Matrix - Matrix, see this page for more information: http://vocab.ices.dk/?ref=55

DEPHL - Depth lower of a depth range (the upper depth value can be found in the “Depth” field)

QFLAG - Qualifier flag, see this page for a complete list: http://vocab.ices.dk/?ref=180

BASIS - Basis of determination, the possible values are: D - Dry weight ; L - Lipid weight (i.e., fat weight); W - Wet weight (i.e., fresh weight)

Depth Class - Depth class ranges as described on the following page: http://ecosystemdata.ices.dk/Query/DepthClasses.htm. EcoSystemData can be searched for data per depth class 

Age Class - Age of species from age 0 to age 15 years

Length Class - Length of species in centimetres

Sex - Sex of the species, the possible values are: M - male; F - female; U - unknown

DayNight - Used in Fish trawl survey to define if the trawl was done during the day or night

Area - ICES Area

SubArea - ICES Rectangle or Sub division

NOINP - Number of individuals in sub-sample (i.e. 1 individual or number in pool)

Original Value - The original value that was submited to ICES 

Original Unit - The original value that was submited to ICES 

SampleID - An internal ID of the sample that connects measurements from the same sample

MeasurementID - An internal ID of the measurement that allows to trace back the value in the original database

ICES Position Note - A note added by ICES about the geographical position. It is used to indicate estimated or uncertain positions

ICES DateTime Note - A note added by ICES about the DateTime value. It is used to indicate estimated or uncertain DateTime values

